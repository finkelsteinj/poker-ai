class Card:
    def __init__(self, suit, id, value, isInHand=False, isOnTable=False):
        self.suit = suit
        self.id = id
        self.value = value
        self.isInHand = isInHand
        self.isOnTable = isOnTable
'''
    def shuffle():


    def deal():

'''