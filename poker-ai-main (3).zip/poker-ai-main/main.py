from Poker import Poker
from Player import Player
from Card import Card

if __name__ == '__main__':
    Poker()
